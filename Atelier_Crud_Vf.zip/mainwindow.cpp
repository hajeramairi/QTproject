#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "etudiant.h"
#include <QMessageBox>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
ui->setupUi(this);
ui->tabetudiant->setModel(tmppersonnel.afficher());

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pb_ajouter_clicked()
{
    int NumP = ui->lineEdit_id->text().toInt();
    QString Nom= ui->lineEdit_nom->text();
    QString Fonction= ui->lineEdit_prenom->text();
    int Salaire = ui->lineEdit_Salaire->text().toInt();
    int Chef = ui->lineEdit_Chef->text().toInt();
  Personnel p(NumP,Nom,Fonction,Salaire,Chef);
  bool test=p.ajouter();
  if(test)
{ui->tabetudiant->setModel(tmppersonnel.afficher());//refresh
QMessageBox::information(nullptr, QObject::tr("Ajouter un Personnel"),
                  QObject::tr("Personnel ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
      QMessageBox::critical(nullptr, QObject::tr("Ajouter un étudiant"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);


}

void MainWindow::on_pb_supprimer_clicked()
{
int NumP = ui->lineEdit_id->text().toInt();
bool test=tmppersonnel.supprimer(NumP);
if(test)
{ui->tabetudiant->setModel(tmppersonnel.afficher());//refresh
    QMessageBox::information(nullptr, QObject::tr("Supprimer un Personnel"),
                QObject::tr("Personnel supprimé.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);

}
else
    QMessageBox::critical(nullptr, QObject::tr("Supprimer un Personnel"),
                QObject::tr("Erreur !.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);


}
